import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Set;

public class Write_To_File {

    public static void main(String[] args) throws IOException {
        String path = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        FileInputStream in = new FileInputStream(path);
        FileOutputStream out=new FileOutputStream("C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\02.WriteToFileOutput.txt");
        Set<Character> punctuationTable = Set.of(',', '.', '!', '?');
        int oneByte = in.read();

        while (oneByte != -1) {
            char symbol=(char) oneByte;
            if (!punctuationTable.contains(symbol)){
                out.write(symbol);
            }

            oneByte = in.read();
        }


    }

}