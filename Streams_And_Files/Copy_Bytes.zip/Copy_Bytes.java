import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Copy_Bytes {
    public static void main(String[] args) throws IOException {
        String path = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        FileInputStream in=new FileInputStream(path);
        FileOutputStream out=new FileOutputStream("C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\03.CopyBytesOutput.txt");
        int oneByte= in.read();
        while (oneByte!=-1){
            if(oneByte==10 || oneByte==32){
                out.write(oneByte);
            }else {
                String digit=String.valueOf(oneByte);
                for (int i = 0; i < digit.length(); i++) {
                    out.write(digit.charAt(i));
                }

            }
            oneByte= in.read();
        }
        in.close();
        out.close();
    }
}