import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

public class Sort_Lines {

    public static void main(String[] args) throws IOException {
        String path = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        Path paths = Paths.get(path);
        FileInputStream in = new FileInputStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String outputPath = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\06.SortLinesOutput.txt";
        PrintWriter writer = new PrintWriter(outputPath);
        List<String> lineList = Files.readAllLines(paths);
        Collections.sort(lineList);
        lineList.stream().forEach(e -> writer.println(e) );
        writer.close();
    }
}