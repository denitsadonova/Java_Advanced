import java.io.*;


public class Write_Every_Third_Line {

    public static void main(String[] args) throws IOException {
        String path = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        FileInputStream in = new FileInputStream(path);
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        PrintWriter writer=new PrintWriter("C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\05.WriteEveryThirdLineOutput.txt");
        String line = reader.readLine();
        int counter = 1;
        while (line != null) {

            line = reader.readLine();
            counter++;
            if (counter % 3 == 0) {
                writer.println(line);
            }
        }
        writer.close();
    }
}