import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class Extract_Integers {
    public static void main(String[] args) throws FileNotFoundException {
        String path = "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\input.txt";
        FileInputStream in = new FileInputStream(path);
        Scanner scanner = new Scanner(in);
        PrintWriter out =
                new PrintWriter(new FileOutputStream( "C:\\Users\\laptop\\IdeaProjects\\Streams_And_Files\\src\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\04.ExtractIntegersOutput.txt"));

        while (scanner.hasNext()){
            if (scanner.hasNextInt()){
                out.println(scanner.nextInt());
            }else {
                scanner.next();
            }
        }
        out.close();
    }
}